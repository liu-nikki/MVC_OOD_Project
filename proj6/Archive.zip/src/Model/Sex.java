package Model;

public enum Sex {
  MALE,
  FEMALE
}
