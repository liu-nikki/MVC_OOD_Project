package Model;

public enum Species {
  DRILL,
  GUEREZA,
  HOWLER,
  MANGABEY,
  SAKI,
  SPIDER,
  SQUIRREL,
  TAMARIN
}
